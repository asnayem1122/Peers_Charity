#pragma once
#include "Book.h"
#include <vector>
#include <iostream>

class Library {
private:
    std::vector<Book> inventory;
public:
    void addBook(const Book& b);
    void displayBooks() const;
    bool borrowBook(const std::string& isbn);
    bool returnBook(const std::string& isbn);
};
