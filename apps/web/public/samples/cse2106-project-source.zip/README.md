# Library Management System (CSE 2106 OOP Sessional Project)

Developed for CSE 2106 Sessional by Tanvir Hasan (Batch 12).

## Compilation
```bash
g++ -std=c++17 main.cpp Library.cpp -o library_app
./library_app
```

## Features
- Dynamic Book catalog with ISBN hashing
- Student borrowing ledger with fine calculation ($2/day after 14 days)
- Persistent disk storage using CSV serialization
