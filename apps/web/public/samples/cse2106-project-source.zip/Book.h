#pragma once
#include <string>

class Book {
private:
    std::string isbn;
    std::string title;
    std::string author;
    bool isAvailable;
public:
    Book(std::string i, std::string t, std::string a) 
      : isbn(i), title(t), author(a), isAvailable(true) {}
    std::string getIsbn() const { return isbn; }
    std::string getTitle() const { return title; }
    bool getAvailable() const { return isAvailable; }
    void setAvailable(bool avail) { isAvailable = avail; }
};
