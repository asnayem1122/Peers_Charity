#include "Library.h"

void Library::addBook(const Book& b) {
    inventory.push_back(b);
}

void Library::displayBooks() const {
    std::cout << "\n=== Library Inventory ===" << std::endl;
    for (const auto& b : inventory) {
        std::cout << "[" << b.getIsbn() << "] " << b.getTitle() 
                  << " (" << (b.getAvailable() ? "AVAILABLE" : "BORROWED") << ")\n";
    }
}

bool Library::borrowBook(const std::string& isbn) {
    for (auto& b : inventory) {
        if (b.getIsbn() == isbn && b.getAvailable()) {
            b.setAvailable(false);
            return true;
        }
    }
    return false;
}

bool Library::returnBook(const std::string& isbn) {
    for (auto& b : inventory) {
        if (b.getIsbn() == isbn && !b.getAvailable()) {
            b.setAvailable(true);
            return true;
        }
    }
    return false;
}
