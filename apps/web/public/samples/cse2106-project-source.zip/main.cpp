#include "Library.h"
#include <iostream>

int main() {
    Library lib;
    lib.addBook(Book("978-0131103627", "The C Programming Language", "K&R"));
    lib.addBook(Book("978-0132350884", "Clean Code", "Robert C. Martin"));
    lib.addBook(Book("978-0201633610", "Design Patterns", "GoF"));

    lib.displayBooks();
    std::cout << "\nBorrowing Clean Code..." << std::endl;
    lib.borrowBook("978-0132350884");
    lib.displayBooks();

    return 0;
}
